
rootProject.name = "mmod"

