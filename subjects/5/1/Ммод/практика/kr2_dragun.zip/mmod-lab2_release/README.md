# mmod
Математическое моделирование, дистанционка, 2022

working setup: 
1) IDEA COMMUNITY 2022.2.3 + Java 15.0.8 aka azul-15
2) Clone project
3) Sync